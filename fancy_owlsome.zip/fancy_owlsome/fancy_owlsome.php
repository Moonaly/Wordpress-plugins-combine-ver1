<?php 
 /*
Plugin Name: Fancy Owlsome V2
Plugin URI: https://www.fple.com
description: Owl Carousel 2.3.4, Fonts Awesome 5, Fancybox
Version: 1.0
Author: Fple Sdn Bhd
Author URI: https://www.fple.com
License: GPL2
*/

//Create Setting Menu
add_action('admin_menu', 'fancy_owlsome_menu');
function fancy_owlsome_menu() {

	//create new top-level menu
	add_menu_page('Shopify Checkout Setting', 'Fancy Owlsome', 'administrator', __FILE__, 'fancy_owlsome_page' , plugins_url('/img/settings.png', __FILE__) );

	//call register settings function
	add_action( 'admin_init', 'register_fancy_owlsome' );
}


function register_fancy_owlsome() {
	//register our settings
	register_setting( 'fancy-owlsome-group', 'ch_font_awesome' );
	register_setting( 'fancy-owlsome-group', 'ch_fancybox' );
	register_setting( 'fancy-owlsome-group', 'ch_owlcarousel' );
}

function fancy_owlsome_page() {
?>
<div class="wrap">
<h1>Fancy Owlsome Setting</h1>

<form method="post" action="options.php">
    <?php 
	settings_fields( 'fancy-owlsome-group' );
	do_settings_sections( 'fancy-owlsome-group' );
	$ch_awesome = get_option('ch_font_awesome');
	$ch_carousel = get_option('ch_owlcarousel');
	$ch_fancy = get_option('ch_fancybox');
	?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Owl Carousel?</th>
        <td><input type="checkbox" name="ch_owlcarousel" value="1" <?php if($ch_carousel == '1'){ echo 'checked'; } ?>/></td>
        </tr>
        <tr valign="top">
        <th scope="row">Fancybox?</th>
        <td><input type="checkbox" name="ch_fancybox" value="1" <?php if($ch_fancy == '1'){ echo 'checked'; } ?>/></td>
        </tr>
		<tr valign="top">
        <th scope="row">Font Awesome?</th>
        <td><input type="checkbox" name="ch_font_awesome" value="1" <?php if($ch_awesome == '1'){ echo 'checked'; } ?>/></td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php } 

//Registered CSS & JS
function fpl_recent_file() {
	$ch_awesome = get_option('ch_font_awesome');
	$ch_carousel = get_option('ch_owlcarousel');
	$ch_fancy = get_option('ch_fancybox');
	if($ch_fancy == '1') {
		wp_register_style('fpl_fancy', plugins_url('/assets/css/jquery.fancybox.min.css' ,__FILE__ ));
		wp_enqueue_style('fpl_fancy');
	}
	if( $ch_carousel == '1') {
		wp_register_style('fpl_owl', plugins_url('/assets/css/owl.carousel.min.css' ,__FILE__ ));
		wp_register_style('fpl_owl_thm', plugins_url('/assets/css/owl.theme.default.min.css' ,__FILE__ ));
		wp_enqueue_style('fpl_owl');
		wp_enqueue_style('fpl_owl_thm');
	}
	if($ch_awesome == '1') {
		wp_enqueue_script('fpl_awesome', plugins_url('assets/js/fontawesome.js' ,__FILE__ ));
	}
}
add_action( 'wp_enqueue_scripts', 'fpl_recent_file' );

add_action( 'wp_footer', 'fpl_footer_script' );
function fpl_footer_script(){
	$ch_carousel = get_option('ch_owlcarousel');
	$ch_fancy = get_option('ch_fancybox');
  ?>
	<?php if($ch_carousel == '1'): ?>
		<script src="<?php echo plugins_url('fancy_owlsome/assets/js/owl.carousel.min.js'); ?>"></script>
	<?php endif; 
	if($ch_fancy== '1' ): ?>
		<script src="<?php echo plugins_url('fancy_owlsome/assets/js/jquery.fancybox.min.js'); ?>"></script>
	<?php endif; ?>
  <?php
}